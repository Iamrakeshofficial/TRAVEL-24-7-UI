// import { createSlice } from "@reduxjs/toolkit";

// export const objectData=createSlice({
//     name:"getting",
//     initialState:{
//         data1:[],
        
//     },
//     reducers:{
//         sending1:(state,action)=>{
//           state.data1=action.payload
//         }
       
//     }
// })
// export const{sending1}=objectData.actions
// export default objectData.reducer