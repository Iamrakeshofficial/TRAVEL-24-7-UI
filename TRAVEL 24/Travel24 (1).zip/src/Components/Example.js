import React from 'react'

function Example() {
    const data={
        datasets:[{
            data:[10,20,30]
        }],
        labels:[
            'Red',
            'Yellow',
            'Blue'
        ]
    }
  return (
    <div>
     
    </div>
  )
}

export default Example
