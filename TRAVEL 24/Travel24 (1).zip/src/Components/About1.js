import React from 'react'
import { Container, Row, Col, Card, Button  } from 'react-bootstrap';
import Group104 from "../Components/Images/Group 104.jpg"
import Group35 from "../Components/Images/Group 35.jpg"
const About=()=>{
    return ( 
    
    <div class="about1">
        <img src={Group104} alt="image of bus" width={1583}></img>
        
        <Container>
        
            <Row>
                {/* <Col>
                <marquee><h1 style={{"color":"green"}}> Welcome To Travel 24/7</h1></marquee>
                </Col> */}
                <Col sm="8">
                <br></br>
                
                    <div className='smallimg'>
                <h1>Welcome to 24/7 Travel </h1>
                </div>
                
                <h5 className='sidepara'>This Application Travel 24/7 provides a web-based buying bus ticket functions.
                     Passengers can buy bus tickets through this travel  Application  and
                     no need to queue up to buy bus tickets in the counter.
                      customers can buy bus tickets 24 hours a day,
                      7 days a week or cancel a Ticket  over the Internet and 
                     they can check the availability of the bus ticket online.
                      Travel 24/7 is popular due to its adequate, safe and on-time bus services.
                      Several types of buses run by Travel 24/7 help in connecting different routes.
                      Travel 24/7 proficiently strives in maintaining 
                     its quality and on time bus services across various city routes.Travel 24/7 delivering an affordable
                      bus travel experience in the long run.
                     </h5>
                </Col>
                <Col sm="4">
                    <div className='sideimg'>
                    <img src={Group35} alt="image of bus" width={500}></img>
                </div>
                </Col>
                
            </Row>
            {/* <Row>
            <Col lg='8'>
            <p>When visitors go to your website, the first place they go is your landing page.</p>
    <p>If they have an interest past your landing page, they will probably go to your “About Us” page to learn more.
         When a website visitor decides to go to the “About Us” page for your Travel Agency, he or she is on a fact-finding mission, as well as looking for the “story” of your Travel Agency.</p><br></br>    <p>It’s crucial that your “About Us” page says what goods or services your Travel Agency provides.</p>
    
            </Col>
            <Col>
            <Card style={{ width: '100%' }}>
                <Card.Img variant="top" src="https://s3-ap-southeast-1.amazonaws.com/rb-plus/BI/APP/IND/WM/10283/575/FR/L/Co3rhl.jpeg" />
                <Card.Body>
                    <Card.Title>Travel 24/7</Card.Title>
                    <Card.Text>
                    
                    </Card.Text>
                    <Button variant="primary">Go somewhere</Button>
                </Card.Body>
                </Card>
            </Col>
            </Row>
        </Container>
    <center></center> 
    <p>When visitors go to your website, the first place they go is your landing page.</p>
    <p>If they have an interest past your landing page, they will probably go to your “About Us” page to learn more.
         When a website visitor decides to go to the “About Us” page for your Travel Agency, he or she is on a fact-finding mission, as well as looking for the “story” of your Travel Agency.</p><br></br>    <p>It’s crucial that your “About Us” page says what goods or services your Travel Agency provides.</p>
    <p>Organization Name“Travel is the main thing you purchase that makes you more extravagant”. We, at Organization Name’, swear by this and put stock in satisfying travel dreams that make you perpetually rich constantly.We have been moving excellent encounters for a considerable length of time through our cutting-edge planned occasion bundles and other fundamental travel administrations. We rouse our clients to carry on with a rich life, brimming with extraordinary travel encounters.Through our exceptionally curated occasion bundles, we need to take you on an adventure where you personally enjoy the stunning magnificence of America and far-off terrains. We need you to observe sensational scenes that are a long way past your creative ability.The powerful inclination of American voyagers to travel more nowadays is something that keeps us inspired to satisfy our vacation necessities. Our vision to give you a consistent occasion encounter makes us one of the main visit administrators in the regularly extending travel industry.To guarantee that you have a satisfying occasion and healthy encounters, all our vacation administrations are available to your no matter what. On your universal occasion, we guarantee that you are very much outfitted with outside trade (Forex Cards, Currency Notes), visa, and travel protection.We are the pioneers of outside trade in America, and booking forex online is basic and advantageous for us.Our online visa administrations are exceptional and make the bulky procedure of booking visas a cake stroll for clients. We likewise give exceptional visa, forex, and travel protection and outside settlement administrations for understudies voyaging abroad for study.Regardless of whether it’s reserving flights or inns for your movement, Company Name offers everything under one umbrella. We likewise have journey occasions for individuals who are searching for solace and reasonable extravagance.We offer the best limits on our top-rated visit bundles to clients who pick our viable administrations over and over. How about we remind you indeed that we don’t expect to be your visit and travel specialists; we endeavor to be your vacation accomplices until the end of time.</p> 
    <Container>
    <Col>
            <Card style={{ width: '100%' }}>
                <Card.Img variant="top" src="https://3.bp.blogspot.com/-Yd8ylGX_VA8/XMBmUDNNrbI/AAAAAAABVuY/IZ0ynOelgUYy9M_poj6EBVB8yoJv9TfQgCLcBGAs/s1600/DSC_2985.jpg" />
                <Card.Body>
                    <Card.Title>Travel 24/7</Card.Title>
                    <Card.Text>
                    
                    </Card.Text>
                    <Button variant="primary">Go somewhere</Button>
                </Card.Body>
                </Card>
            </Col>
            </Container>

    <div class='about'>
      <h3>we provides services</h3> 
      <b><h6>morning start</h6> 
      <h6>orange Tours and Travel</h6>
      <h6>dolphin Bus</h6>
      <h6>geepee Travels</h6>
      <h6>Universalbus services</h6>
      <h6>Gujart Travels</h6>
      <h6>SRS Travels and Logistics Private Limited</h6>
      <h6>Aruna Travels</h6>
      <h6>Vijay Travels</h6>
      <h6>PVR Travels</h6>
      <h6>Gaytri Travels</h6>
      <h6>Kavari Travels</h6>
      <h6>love Birds Travels</h6>
      <h6>Red travels</h6>
       <h6>yellow Travels</h6>
       <h6>morning start</h6></b>
       </div> */}
       
       </Container>
       </div>
       )}
       export default About;

